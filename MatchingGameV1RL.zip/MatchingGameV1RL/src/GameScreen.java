/**Programmer: Raymond Lam
 * Date: May 10, 2022
 * ICS4U1-02
 * Matching Game
 * This program uses arrays to simulate a matching game. 
 * A grid of cards will be displayed and the user is to select two cards at a time
 * looking for matching cards. The goal of this game is to see how quickly 
 * the user can find all the matches.
 * 
 * Extra Features
 * - Menu Screen
 * - When play button is pressed it says game started
 * - Counts the number of tries it takes for the user to win
 * - Winning text
 * - Counts the number of matches made
 * - Extra pictures
 * - Restart Button
 */

//import libraries
import java.util.*;
import javax.swing.ImageIcon;
public class GameScreen extends javax.swing.JFrame {
    
    //set array lists
    ArrayList<String> cards = new ArrayList();
    ArrayList<String> set = new ArrayList();
    
    //set icon objects
    ImageIcon a = new ImageIcon(getClass().getResource("/Resource/Mushroom1 (1).jpg"));
    ImageIcon b = new ImageIcon(getClass().getResource("/Resource/MarioStar.jpg"));
    ImageIcon c = new ImageIcon(getClass().getResource("/Resource/blueshell.jpg"));
    ImageIcon d = new ImageIcon(getClass().getResource("/Resource/fireflower.jpg"));
    ImageIcon e = new ImageIcon(getClass().getResource("/Resource/fruit.jpg"));
    ImageIcon f = new ImageIcon(getClass().getResource("/Resource/Penguinsuit.jpg"));
    ImageIcon back = new ImageIcon(getClass().getResource("/Resource/marioblock.jpg"));
    ImageIcon done = new ImageIcon(getClass().getResource("/Resource/checkmarkdone.jpg"));
    
    //set variables
    int count, c1, c2, card1, card2;
    int cardsLeft = 12;
    int[] change = new int [12];
    
    //game does not start yet
    boolean gameStarted = false;
    /**
     * Creates new form GameScreen
     */
    public GameScreen() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        textOutput = new javax.swing.JTextField();
        guessAgainButton = new javax.swing.JButton();
        restartButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        playButton = new javax.swing.JButton();
        Card4 = new javax.swing.JButton();
        Card1 = new javax.swing.JButton();
        Card2 = new javax.swing.JButton();
        Card5 = new javax.swing.JButton();
        Card6 = new javax.swing.JButton();
        Card7 = new javax.swing.JButton();
        Card8 = new javax.swing.JButton();
        Card3 = new javax.swing.JButton();
        Card9 = new javax.swing.JButton();
        Card10 = new javax.swing.JButton();
        Card11 = new javax.swing.JButton();
        Card12 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 255, 255));
        jLabel2.setText("Match the pairs to Win!");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 230, -1));

        textOutput.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        textOutput.setForeground(new java.awt.Color(0, 51, 204));
        textOutput.setText("     Click the Play button to start. Make sure to click Guess Again after each guess.");
        getContentPane().add(textOutput, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 550, -1));

        guessAgainButton.setBackground(new java.awt.Color(255, 153, 51));
        guessAgainButton.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        guessAgainButton.setForeground(new java.awt.Color(255, 255, 255));
        guessAgainButton.setText("Guess Again");
        guessAgainButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        guessAgainButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guessAgainButtonActionPerformed(evt);
            }
        });
        getContentPane().add(guessAgainButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 140, 120, 70));

        restartButton.setBackground(new java.awt.Color(0, 153, 102));
        restartButton.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        restartButton.setForeground(new java.awt.Color(255, 255, 255));
        restartButton.setText("Restart");
        restartButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        restartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restartButtonActionPerformed(evt);
            }
        });
        getContentPane().add(restartButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 220, 120, 30));

        exitButton.setBackground(new java.awt.Color(255, 51, 51));
        exitButton.setForeground(new java.awt.Color(255, 255, 255));
        exitButton.setText("Exit");
        exitButton.setBorder(null);
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 380, 50, 20));

        playButton.setBackground(new java.awt.Color(102, 153, 255));
        playButton.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        playButton.setForeground(new java.awt.Color(255, 255, 255));
        playButton.setText("Play");
        playButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        playButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playButtonActionPerformed(evt);
            }
        });
        getContentPane().add(playButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 120, 50));

        Card4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card4MouseClicked(evt);
            }
        });
        getContentPane().add(Card4, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, 90, 90));

        Card1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card1.setBorder(null);
        Card1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card1MouseClicked(evt);
            }
        });
        getContentPane().add(Card1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 90, 90));

        Card2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card2MouseClicked(evt);
            }
        });
        getContentPane().add(Card2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, 90, 90));

        Card5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card5MouseClicked(evt);
            }
        });
        getContentPane().add(Card5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 90, 90));

        Card6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card6MouseClicked(evt);
            }
        });
        getContentPane().add(Card6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 90, 90));

        Card7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card7MouseClicked(evt);
            }
        });
        getContentPane().add(Card7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 180, 90, 90));

        Card8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card8MouseClicked(evt);
            }
        });
        getContentPane().add(Card8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, 90, 90));

        Card3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card3MouseClicked(evt);
            }
        });
        getContentPane().add(Card3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 90, 90));

        Card9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card9MouseClicked(evt);
            }
        });
        getContentPane().add(Card9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 90, 90));

        Card10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card10MouseClicked(evt);
            }
        });
        getContentPane().add(Card10, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 90, 90));

        Card11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card11MouseClicked(evt);
            }
        });
        getContentPane().add(Card11, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 290, 90, 90));

        Card12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/marioblock.jpg"))); // NOI18N
        Card12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Card12MouseClicked(evt);
            }
        });
        getContentPane().add(Card12, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, 90, 90));

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Back");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 380, 50, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/luiji.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 260, 70, 110));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resource/pokerBoard.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 410));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        //exits program
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void playButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playButtonActionPerformed
        //starts game
        gameStarted = true;
        
        //output to user game has started
        textOutput.setText("----------------------------------------Game Started!---------------------------------");
        
        //set change array put cards in pairs
        for(int z=0; z <=11; z++){
            change[z] = 1;
        }
        
        //assign cards at random
        String temp;
        for(int x=0; x<=5; x++){
            for(int y=1; y<=2; y++){
                temp = Integer.toString(x);
                set.add(temp);
                
            }
        }
        //random number between 0 and 11 to set random card
        for(int x=0; x<=11; x++){
            double index = Math.floor(Math.random() * (12-x));
            int index1 = (int) index;
            cards.add(set.get(index1));
            set.remove(set.get(index1));
        }
    }//GEN-LAST:event_playButtonActionPerformed

    private void Card1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card1MouseClicked
        //gets index 0 from array
        String temp = cards.get(0);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card1.setIcon(a);
        } else if (temp.equals ("1")) {
            Card1.setIcon(b);
        } else if (temp.equals ("2")) {
            Card1.setIcon(c);
        } else if (temp.equals ("3")) {
            Card1.setIcon(d);
        } else if (temp.equals ("4")) {
            Card1.setIcon(e);
        } else if (temp.equals ("5")) {
            Card1.setIcon(f);
        } 
        
        //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[0] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[0] = 0;
        }
    }//GEN-LAST:event_Card1MouseClicked

    private void Card2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card2MouseClicked
        //gets index 1 from array
        String temp = cards.get(1);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card2.setIcon(a);
        } else if (temp.equals ("1")) {
            Card2.setIcon(b);
        } else if (temp.equals ("2")) {
            Card2.setIcon(c);
        } else if (temp.equals ("3")) {
            Card2.setIcon(d);
        } else if (temp.equals ("4")) {
            Card2.setIcon(e);
        } else if (temp.equals ("5")) {
            Card2.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[1] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[1] = 0;
        }
    }//GEN-LAST:event_Card2MouseClicked

    private void Card3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card3MouseClicked
        //gets index 2 from array
        String temp = cards.get(2);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card3.setIcon(a);
        } else if (temp.equals ("1")) {
            Card3.setIcon(b);
        } else if (temp.equals ("2")) {
            Card3.setIcon(c);
        } else if (temp.equals ("3")) {
            Card3.setIcon(d);
        } else if (temp.equals ("4")) {
            Card3.setIcon(e);
        } else if (temp.equals ("5")) {
            Card3.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[2] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[2] = 0;
        }
    }//GEN-LAST:event_Card3MouseClicked

    private void Card4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card4MouseClicked
        //gets index 3 from array
        String temp = cards.get(3);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card4.setIcon(a);
        } else if (temp.equals ("1")) {
            Card4.setIcon(b);
        } else if (temp.equals ("2")) {
            Card4.setIcon(c);
        } else if (temp.equals ("3")) {
            Card4.setIcon(d);
        } else if (temp.equals ("4")) {
            Card4.setIcon(e);
        } else if (temp.equals ("5")) {
            Card4.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[3] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[3] = 0;
        }
    }//GEN-LAST:event_Card4MouseClicked

    private void Card5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card5MouseClicked
        //gets index 4 from array
        String temp = cards.get(4);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card5.setIcon(a);
        } else if (temp.equals ("1")) {
            Card5.setIcon(b);
        } else if (temp.equals ("2")) {
            Card5.setIcon(c);
        } else if (temp.equals ("3")) {
            Card5.setIcon(d);
        } else if (temp.equals ("4")) {
            Card5.setIcon(e);
        } else if (temp.equals ("5")) {
            Card5.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[4] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[4] = 0;
        }
    }//GEN-LAST:event_Card5MouseClicked

    private void Card6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card6MouseClicked
        //gets index 5 from array
        String temp = cards.get(5);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card6.setIcon(a);
        } else if (temp.equals ("1")) {
            Card6.setIcon(b);
        } else if (temp.equals ("2")) {
            Card6.setIcon(c);
        } else if (temp.equals ("3")) {
            Card6.setIcon(d);
        } else if (temp.equals ("4")) {
            Card6.setIcon(e);
        } else if (temp.equals ("5")) {
            Card6.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[5] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[5] = 0;
        }
    }//GEN-LAST:event_Card6MouseClicked

    private void Card7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card7MouseClicked
        //gets index 6 from array 
        String temp = cards.get(6);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card7.setIcon(a);
        } else if (temp.equals ("1")) {
            Card7.setIcon(b);
        } else if (temp.equals ("2")) {
            Card7.setIcon(c);
        } else if (temp.equals ("3")) {
            Card7.setIcon(d);
        } else if (temp.equals ("4")) {
            Card7.setIcon(e);
        } else if (temp.equals ("5")) {
            Card7.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[6] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[6] = 0;
        }
    }//GEN-LAST:event_Card7MouseClicked

    private void Card8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card8MouseClicked
        //gets index 7 from array
        String temp = cards.get(7);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card8.setIcon(a);
        } else if (temp.equals ("1")) {
            Card8.setIcon(b);
        } else if (temp.equals ("2")) {
            Card8.setIcon(c);
        } else if (temp.equals ("3")) {
            Card8.setIcon(d);
        } else if (temp.equals ("4")) {
            Card8.setIcon(e);
        } else if (temp.equals ("5")) {
            Card8.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[7] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[7] = 0;
        }
    }//GEN-LAST:event_Card8MouseClicked

    private void Card9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card9MouseClicked
        //gets index 8 from array
        String temp = cards.get(8);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card9.setIcon(a);
        } else if (temp.equals ("1")) {
            Card9.setIcon(b);
        } else if (temp.equals ("2")) {
            Card9.setIcon(c);
        } else if (temp.equals ("3")) {
            Card9.setIcon(d);
        } else if (temp.equals ("4")) {
            Card9.setIcon(e);
        } else if (temp.equals ("5")) {
            Card9.setIcon(f);
        } 
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[8] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[8] = 0;
        }
    }//GEN-LAST:event_Card9MouseClicked

    private void Card10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card10MouseClicked
        //gets index 9 from array
        String temp = cards.get(9);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card10.setIcon(a);
        } else if (temp.equals ("1")) {
            Card10.setIcon(b);
        } else if (temp.equals ("2")) {
            Card10.setIcon(c);
        } else if (temp.equals ("3")) {
            Card10.setIcon(d);
        } else if (temp.equals ("4")) {
            Card10.setIcon(e);
        } else if (temp.equals ("5")) {
            Card10.setIcon(f);
        }
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[9] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[9] = 0;
        }
    }//GEN-LAST:event_Card10MouseClicked

    private void Card11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card11MouseClicked
        //gets index 10 from array
        String temp = cards.get(10);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card11.setIcon(a);
        } else if (temp.equals ("1")) {
            Card11.setIcon(b);
        } else if (temp.equals ("2")) {
            Card11.setIcon(c);
        } else if (temp.equals ("3")) {
            Card11.setIcon(d);
        } else if (temp.equals ("4")) {
            Card11.setIcon(e);
        } else if (temp.equals ("5")) {
            Card11.setIcon(f);
        }
         //changes card to icon
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[10] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[10] = 0;
        }
    }//GEN-LAST:event_Card11MouseClicked

    private void Card12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Card12MouseClicked
        //gets index 11 from array
        String temp = cards.get(11);
        
        //checks the random picture that was picked and set icon to button
        if (temp.equals ("0")) {
            Card12.setIcon(a);
        } else if (temp.equals ("1")) {
            Card12.setIcon(b);
        } else if (temp.equals ("2")) {
            Card12.setIcon(c);
        } else if (temp.equals ("3")) {
            Card12.setIcon(d);
        } else if (temp.equals ("4")) {
            Card12.setIcon(e);
        } else if (temp.equals ("5")) {
            Card12.setIcon(f);
        }
         //changes card to icon
         
        count ++;
        if (count == 1) {
            c1 = Integer.parseInt(temp);
            change[11] = 0;
        } else if (count == 2) {
            c2 = Integer.parseInt(temp);
            change[11] = 0;
        }
    }//GEN-LAST:event_Card12MouseClicked
    //set variables
    int pairs = 0;
    int tries = 0;
    private void guessAgainButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guessAgainButtonActionPerformed
        //every time guess button pressed increase number of tries
        tries++;
        
        //declare variable
        count = 0;
        
        //output number of matches found
        textOutput.setText(String.valueOf("\t\t" + pairs + " cards matching..."));
        
        //if card is matching shows done icon
        if (c1==c2){
            for (int y=1; y<=2; y++) {
                if (change[0]==0){
                    
                    //sets done icon
                    Card1.setIcon(done);  
                    
                    //adds 1 to pair variable
                    pairs = pairs + 1;
                    
                    change[0]=2;
                } else if (change[1]==0) {
                    Card2.setIcon(done);
                    pairs = pairs + 1;
                    
                    change[1]=2;
                } else if (change[2]==0) {
                    Card3.setIcon(done);
                    pairs = pairs + 1;
                   
                    change[2]=2;
                } else if (change[3]==0) {
                    Card4.setIcon(done);
                    pairs = pairs + 1;
                   
                    change[3]=2;
                } else if (change[4]==0) {
                    Card5.setIcon(done);
                    pairs = pairs + 1;
                  
                    change[4]=2;
                } else if (change[5]==0) {
                    Card6.setIcon(done);
                    pairs = pairs + 1;
                 
                    change[5]=2;
                } else if (change[6]==0) {
                    Card7.setIcon(done);
                    pairs = pairs + 1;
              
                    change[6]=2;
                } else if (change[7]==0) {
                    Card8.setIcon(done);
                    pairs = pairs + 1;
                
                    change[7]=2;
                } else if (change[8]==0) {
                    Card9.setIcon(done);
                    pairs = pairs + 1;
              
                    change[8]=2;
                } else if (change[9]==0) {
                    Card10.setIcon(done);
                    pairs = pairs + 1;
            
                    change[9]=2;
                } else if (change[10]==0) {
                    Card11.setIcon(done);
                    pairs = pairs + 1;
               
                    change[10]=2;
                } else if (change[11]==0) {
                    Card12.setIcon(done);
                    pairs = pairs + 1;
                
                    change[11]=2;
                } 
                    //output number of matches found
                    textOutput.setText(String.valueOf("\t\t" + pairs + " cards matching!"));
                    
                    //when all cards match output congrats message
                    //also outputs number of tries user had
                    if(pairs == 12){
                        textOutput.setText(String.valueOf("Congrats all cards are matching you win! You did it in " + tries + " tries!"));
                    }
            }
        } else {
            //cards don't match flip back and show back icon
            for (int y=1; y<=2; y++){
                if (change[0]==0){
                    Card1.setIcon(back);
                    change[0]=1;
                } else if (change[1]==0) {
                    Card2.setIcon(back);
                    change[1]=1;
                } else if (change[2]==0) {
                    Card3.setIcon(back);
                    change[2]=1;
                } else if (change[3]==0) {
                    Card4.setIcon(back);
                    change[3]=1;
                } else if (change[4]==0) {
                    Card5.setIcon(back);
                    change[4]=1;
                } else if (change[5]==0) {
                    Card6.setIcon(back);
                    change[5]=1;
                } else if (change[6]==0) {
                    Card7.setIcon(back);
                    change[6]=1;
                } else if (change[7]==0) {
                    Card8.setIcon(back);
                    change[7]=1;
                } else if (change[8]==0) {
                    Card9.setIcon(back);
                    change[8]=1;
                } else if (change[9]==0) {
                    Card10.setIcon(back);
                    change[9]=1;
                } else if (change[10]==0) {
                    Card11.setIcon(back);
                    change[10]=1;
                } else if (change[11]==0) {
                    Card12.setIcon(back);
                    change[11]=1;
                }
            }
        }
       
    }//GEN-LAST:event_guessAgainButtonActionPerformed

    private void restartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restartButtonActionPerformed
        //resets the variables to zero
        pairs = 0;
        tries = 0;
        
        //reset to show starting message
        
        textOutput.setText("Click the Play button to start. Make sure to click Guess Again after each guess.");
        //Start the game ON
        gameStarted = true;

        //set Cards cardback.jpg icon whenever RestartGame button is clicked
        Card1.setIcon(back);
        Card2.setIcon(back);
        Card3.setIcon(back);
        Card4.setIcon(back);
        Card5.setIcon(back);
        Card6.setIcon(back);
        Card7.setIcon(back);
        Card8.setIcon(back);
        Card9.setIcon(back);
        Card10.setIcon(back);
        Card11.setIcon(back);
        Card12.setIcon(back);
        
    }//GEN-LAST:event_restartButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //when back button is pressed go back to main screen
        
        //sets new object window
        MatchingGame window1 = new MatchingGame();
        
        //sets main window visible
        window1.setVisible(true);
        
        //sets this window to invisible
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Card1;
    private javax.swing.JButton Card10;
    private javax.swing.JButton Card11;
    private javax.swing.JButton Card12;
    private javax.swing.JButton Card2;
    private javax.swing.JButton Card3;
    private javax.swing.JButton Card4;
    private javax.swing.JButton Card5;
    private javax.swing.JButton Card6;
    private javax.swing.JButton Card7;
    private javax.swing.JButton Card8;
    private javax.swing.JButton Card9;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton guessAgainButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JButton playButton;
    private javax.swing.JButton restartButton;
    private javax.swing.JTextField textOutput;
    // End of variables declaration//GEN-END:variables
}
